import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from './admine-viwe/navbar/navbar.component';
import { ReportsComponent } from './admine-viwe/reports/reports.component';
import { MachineComponent } from './admine-viwe/machine/machine.component';
import { MachineManagementComponent } from "./admine-viwe/machine-management/machine-management.component";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, NavbarComponent, ReportsComponent, MachineComponent, MachineManagementComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'project3';
}
