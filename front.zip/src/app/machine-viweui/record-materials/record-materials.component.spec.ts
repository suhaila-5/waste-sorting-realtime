import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecordMaterialsComponent } from './record-materials.component';

describe('RecordMaterialsComponent', () => {
  let component: RecordMaterialsComponent;
  let fixture: ComponentFixture<RecordMaterialsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RecordMaterialsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RecordMaterialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
