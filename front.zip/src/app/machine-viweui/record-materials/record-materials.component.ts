import { Component, OnInit } from '@angular/core';
import { WasteSortingMachineService } from '../waste-sorting-machine.service.js';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-record-materials',
  standalone: true, 
  imports: [RouterModule, CommonModule],
  templateUrl: './record-materials.component.html',
  styleUrls: ['./record-materials.component.css'],
  providers: [WasteSortingMachineService],
})
export class RecordMaterialsComponent implements OnInit{
  sortedMaterials: any[] = [];

  constructor(private service: WasteSortingMachineService) {}



  loadRecordMaterials (): void  {
    this.service.getMachines().subscribe({
      next: (machines) => {
        console.log('Full response: ',machines ); 
        this.sortedMaterials = machines.flatMap((machine: any)=>machine.sortedMaterials || []);
        console.log('Loaded sorted materials: ', this.sortedMaterials);
    
      },
      error: (error) => console.error('Error fetching material counts', error),
    });
  }
  ngOnInit(): void {
    console.log('Calling loadRecordMaterials...');
  
    this.loadRecordMaterials(); 
  }
  exportRecords(): void {
    const csvContent =
      'Material ID,Material Name,Sort Status,Sorted At\n' +
      this.sortedMaterials
        .map(
          (material) =>
            `${material.id},${material.name},${material.status},${material.sortedAt}`
        )
        .join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'recorded_materials.csv';
    a.click();
    console.log('Records exported as CSV.');
  }

  clearRecords(): void {
    this.sortedMaterials = [];
    console.log('Sorted materials cleared.');
  }

}
