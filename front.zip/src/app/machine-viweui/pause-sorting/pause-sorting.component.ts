import { Component } from '@angular/core';
import { WasteSortingMachineService } from '../waste-sorting-machine.service';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-pause-sorting',
  standalone: true,
  templateUrl: './pause-sorting.component.html',
  styleUrls: ['./pause-sorting.component.css'],
  providers: [WasteSortingMachineService],
  imports: [RouterModule]
})
export class PauseSortingComponent {
  isPaused = false;

  constructor(private service: WasteSortingMachineService) {}

  togglePause() {
    this.isPaused = !this.isPaused;
    const machineId = 'your-machine-id-here'; // Replace this with actual logic for a specific machine ID.

    if (this.isPaused) {
      console.log('Pausing sorting...');
      this.service.viewNonRecycledSortedMaterialsCount(machineId).subscribe({
        next: () => console.log('Machine paused.'),
        error: (error) => console.error('Error pausing machine', error),
      });
    } else {
      console.log('Resuming sorting...');
      this.service.viewRecycledSortedMaterialsCount(machineId).subscribe({
        next: () => console.log('Machine resumed.'),
        error: (error) => console.error('Error resuming machine', error),
      });
    }
  }
}
