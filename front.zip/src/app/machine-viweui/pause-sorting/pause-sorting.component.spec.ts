import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PauseSortingComponent } from './pause-sorting.component';

describe('PauseSortingComponent', () => {
  let component: PauseSortingComponent;
  let fixture: ComponentFixture<PauseSortingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PauseSortingComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PauseSortingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
