import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators'; 

@Injectable({
  providedIn: 'root',
})
export class WasteSortingMachineService {
 private backendUrl = 'http://localhost:4000/graphql';
 
  constructor(private http: HttpClient) {}
 
  private hashQuery(query: string): string {
    let hash = 0;
    for (let i = 0; i < query.length; i++) {
      hash = Math.imul(31, hash) + query.charCodeAt(i);
    }
    return hash.toString(16);
 
  }

  private postGraphQL(query: string): Observable<any> {
    const hashedQuery = this.hashQuery(query);
    const payload = { query, hashedQuery };
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    return this.http.post(`${this.backendUrl}`, payload, { headers }).pipe(
      catchError((error) => {
        console.error('GraphQL request failed', error);
        return throwError(() => new Error('Failed to fetch data from backend'));
      })
    );
  }
 
  sendUserNotification( userId: string, title: string, message: string ) {
    const query = `
    query {
     mutation{
      
      sendUserNotification(userId: "${userId}", title: "${title}", message: "${message}")
  }
  `;
   return this.postGraphQL(query);

  }
  sendAdminAlert(title: string,message: string ) {
    const query = `
      mutation{
        sendAdminAlert(message: "${message}", title: "${title}")
      }
    `;
    return this.postGraphQL(query);
  }

 getMachines(): Observable<{ name: string; type: string }[]> {
  const query = `
  query {
    getMachines {
      name
      type
    }
  }
`;
return this.postGraphQL(query).pipe(
  map((response: any) => response?.data?.getMachines || [])

    );
   }
  
 
  getMachine(machineId: string): Observable<any> {
    const query = `
      query {
        getMachine(id: "${machineId}") {
         
            id,
            name,
            powerStatus,
         
        }
      }
    `;
    return this.postGraphQL(query);
  }

  // Fetch machine by name
  getMachineByName(name: string): Observable<any> {
    const query = `
      query {
        getMachineByName(name: "${name}") {
          id,
          name,
          powerStatus,
           }
      }
    `;
    return this.postGraphQL(query);
 
  }

  // Fetch machine recyclable materials
  getMachineRecyclMaterials(machineId: string): Observable<any>  {
    const query = `
      query {
        getMachineRecyclMaterials(machineId: "${machineId}") {
          id,
          name,
         
        }
      }
    `;
    return this.postGraphQL(query); }

  // Fetch machine non-recyclable materials
  getMachineNonRecyclMaterials(machineId: string): Observable<any> {
    const query = `
      query {
        getMachineNonRecyclMaterials(machineId: "${machineId}") {
          id,
          name,
          
        }
      }
    `;
    return this.postGraphQL(query);
  }

  // Fetch machine sorted materials
  getMachineSortedMaterials(machineId: string): Observable<any> {
    const query = `
      query {
        getMachineSortedMaterials(machineId: "${machineId}") {
          id,
          name,
          status,
          machineId,
          sortedAt
        }
      }
    `;
    return this.postGraphQL(query);
  }
  

  // Get all unique materials names
 getMaterialsName(): Observable<any>{
     const query = `
       query {
         getMaterialsName
       }
     `;
     return this.postGraphQL(query);
    }

  // Fetch count of non-recycled sorted materials
  viewNonRecycledSortedMaterialsCount(machineId: string): Observable<any> {
    const query = `
      query {
        viewNonRecycledSortedMaterialsCount(machineId: "${machineId}")
      }
    `;
    return this.postGraphQL(query).pipe(
      map((response: any) => response?.data?.viewNonRecycledSortedMaterialsCount || 0)
    );
   }

  // Fetch count of recycled sorted materials
  viewRecycledSortedMaterialsCount(machineId: string) : Observable<any>{
    const query = `
      query {
        viewRecycledSortedMaterialsCount(machineId: "${machineId}")
      }
    `;
    return this.postGraphQL(query).pipe(
      map((response: any) => response?.data?.viewRecycledSortedMaterialsCount || 0)
    );
  }

  // Fetch count of total sorted materials
  viewSortedMaterialsCount(machineId: string) : Observable<any>{
    const query = `
      query {
        viewSortedMaterialsCount(machineId: "${machineId}")
      }
    `;
    return this.postGraphQL(query).pipe(
      map((response: any) => response?.data?.viewSortedMaterialsCount || 0)
    );
  }

  // Fetch Identifiable Materials by Machine ID
  getMachineIdentifiableMaterials(machineId: string): Observable<any> {
    const query = `
      query {
        getMachineIdentifiableMaterials(machineId: "${machineId}") {
          id,
          name,
          category,
          machineId
        }
      }
    `;
    return this.postGraphQL(query);
  }

  // Validate Materials
  validateMaterials(machineId: string, materials: Array<{ name: string }>) : Observable<any>{
    const query = `
      mutation {
        validateMaterials(machineId: "${machineId}", materials: ${JSON.stringify(materials)}) {
          validatedMaterials {
            name,
            category
          }
          invalidMaterials
        }
      }
    `;
    return this.postGraphQL(query);
   }
}


