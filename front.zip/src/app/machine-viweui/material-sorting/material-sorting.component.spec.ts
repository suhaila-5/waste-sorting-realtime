import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MaterialSortingComponent } from './material-sorting.component';

describe('MaterialSortingComponent', () => {
  let component: MaterialSortingComponent;
  let fixture: ComponentFixture<MaterialSortingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MaterialSortingComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MaterialSortingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
