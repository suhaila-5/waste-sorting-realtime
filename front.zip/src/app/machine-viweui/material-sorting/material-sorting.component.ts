import { Component ,OnInit } from '@angular/core';
import { WasteSortingMachineService } from '../waste-sorting-machine.service';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common'; // Import CommonModule

@Component({
  selector: 'app-material-sorting',
  standalone: true,
  imports: [RouterModule,HttpClientModule, CommonModule],
  providers: [WasteSortingMachineService],
  templateUrl: './material-sorting.component.html',
  styleUrls: ['./material-sorting.component.css']
})
export class MaterialSortingComponent implements OnInit{
  sortedMaterials: any[] = [];

  constructor(private service: WasteSortingMachineService) {}
  
  
   ngOnInit(): void {
    this.loadMachineData();
   }
   loadMachineData():void{
     this.service.getMachines().subscribe({
       next: (data) => {
         this.sortedMaterials = data|| [];
         console.log('Sorted materials loaded:', this.sortedMaterials);
         if (!this.sortedMaterials.length) {
           alert('No sorted materials found.');
         }
       },
        error: (error) => {console.error('Error fetching sorted materials', error)
         alert('Failed to load sorted materials. Please try again.');
       },
       });
   }
}
