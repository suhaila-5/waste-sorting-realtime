import { Component, OnInit } from '@angular/core';
import { WasteSortingMachineService } from '../waste-sorting-machine.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-material-identification',
  standalone: true,
  templateUrl: './material-identification.component.html',
  styleUrls: ['./material-identification.component.css'],
  imports: [CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    
  ],
  providers: [WasteSortingMachineService],
})
export class MaterialIdentificationComponent implements OnInit {
 
  materials: string[] = [];
  enteredMaterials = [
    { name: 'plastic' },
    { name: 'metal' },
    { name: 'glass' },
    {name:'wood'},
  ];
  validMaterials: any[] = [];
  invalidMaterials: any[] = [];
  alertMessage = '';

  constructor(private service: WasteSortingMachineService) {}

  ngOnInit(): void {
    
    this.loadMaterials();
    this.validateUserMaterials();
  }
  loadMaterials() {
    this.service.getMaterialsName().subscribe({
      next: (data) => {
        this.materials = data?.data?.getMaterialsName || [];
        console.log('Available materials: ', this.materials);
        if (!this.materials.length) {
          alert('No materials are available for identification.');
        }
      },
      error: (error) =>{ console.error('Error loading material names', error);
      alert('Failed to load materials. Please check your network or server.');
    },
    });
  }


  validateUserMaterials() {
    const machineId = 'some-machine-id'; // Replace this logic with actual dynamic logic

    this.service.validateMaterials(machineId, this.enteredMaterials).subscribe({
      next: (response) => {
        console.log(response);
        this.validMaterials = response.validatedMaterials;
        this.invalidMaterials = response.invalidMaterials;

        if (this.invalidMaterials.length) {
          alert(`Invalid materials: ${this.invalidMaterials.join(', ')}`);
          this.notifyUserOfInvalidMaterials();
        }

        if (this.validMaterials.length) {
          alert(`Valid materials ready for sorting: ${this.validMaterials.map(x => x.name).join(', ')}`);
        
        }
        this.alertAdminIfNecessary();
      },
      error: (error) => {
        console.error('Error validating materials', error);
      }
  });
    }
  
    notifyUserOfInvalidMaterials() {
      const userId = 'user-id-placeholder';
      const title = 'Invalid Materials Detected';
      const message = `The following materials are invalid: ${this.invalidMaterials.join(', ')}`;
  
      this.service.sendUserNotification(userId, title, message).subscribe({
        next: () => console.log('User notified of invalid materials.'),
        error: (error) => console.error('Error sending user notification', error),
  
      });
    }
  alertAdminIfNecessary() {
    if (this.validMaterials.length === 0) {
      const title = 'Machine Capacity Alert';
      const message = 'The entered materials are too big for the machine to handle.';

      this.service.sendAdminAlert(title, message).subscribe({
        next: () => console.log('Admin alerted about machine capacity issue.'),
        error: (error) => console.error('Error sending admin alert', error),
      });
    }
    
  }
 } 

