import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MaterialIdentificationComponent } from './material-identification.component';

describe('MaterialIdentificationComponent', () => {
  let component: MaterialIdentificationComponent;
  let fixture: ComponentFixture<MaterialIdentificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MaterialIdentificationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MaterialIdentificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
