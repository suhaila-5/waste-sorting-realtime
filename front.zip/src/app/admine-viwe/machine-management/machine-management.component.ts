import { Component, inject, OnInit } from '@angular/core';
import {  HttpClientModule } from '@angular/common/http';
import { MachineService } from './machine.service'; // Adjust to your correct path
import { GoogleMap, GoogleMapsModule } from '@angular/google-maps';
import { CommonModule } from '@angular/common';
import { Machine } from '../machine/machine.model';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NavbarComponent } from "../navbar/navbar.component";

@Component({
  selector: 'app-machine-management',
  standalone: true,
  templateUrl: './machine-management.component.html',
  styleUrls: ['./machine-management.component.scss'],
  imports: [CommonModule, GoogleMapsModule, FormsModule, RouterLink, HttpClientModule, MachineManagementComponent, NavbarComponent] // Add any necessary imports like CommonModule or other Angular components
 // Add any necessary imports like CommonModule or other Angular components
})
export class MachineManagementComponent implements OnInit {
  currentView: string = ''; // Default view
  mapCenter = { lat: 30.0444, lng: 31.2357 }; // Default center (e.g., Cairo, Egypt)
  mapZoom = 10;
  machines: Machine[] = []; // Initialize as an empty array with type safety
  newMachineName: string = '';
  newMachineLatitude: number | undefined;
  newMachineLongitude: number | undefined;


  machineName: string = ''; // Bind this to the input field
  filteredMachines: any[] = []; // Array to hold the filtered machine

  constructor(private machineService: MachineService) {}

  ngOnInit() {
    this.getMachines();; // Fetch machines on component initialization
  }

  setView(view: string) {
    this.currentView = view;
  }

  getMachines() {
    this.machineService.getMachines().subscribe(
      (data: Machine[]) => {
        this.machines = data; // Directly assign the response data
      },
      (error) => {
        console.error('Error fetching machines:', error);
      }
    );
  }


  onMachineClick(machine: Machine) {
    console.log('Machine clicked:', machine);
  }

  onAddMachine() {
    if (this.newMachineName && this.newMachineLatitude && this.newMachineLongitude) {
      const newMachine = {
        id:1,
        name: this.newMachineName,
        latitude: this.newMachineLatitude,
        longitude: this.newMachineLongitude,
        identifiableMaterialsList: [
          { name: 'plastic bottles', category: 'recyclable' }
        ],
      };
      this.machineService.create(newMachine).subscribe(
        () => {
          this.getMachines(); // Refresh machines list after adding
          this.clearForm(); // Clear form fields after adding
        },
        (error) => {
          console.error('Error adding machine:', error);
        }
      );
    } else {
      console.warn('Please fill in all required fields');
    }
  }

  onSearchMachine(): void {
    // Filter the machines based on the name entered in the input field
    this.filteredMachines = this.machines.filter(machine =>
      machine.name.toLowerCase().includes(this.machineName.toLowerCase())
    );
  }

  onRemoveMachine(machineId: string): void {
    // Call the removeMachine method from the service
    this.machineService.removeMachine(machineId).subscribe({
      next: (response) => {
        console.log('Machine removed:', response); // Handle success response
        this.machines = this.machines.filter(machine => machine.id !== machineId); // Remove from local list
        this.filteredMachines = []; // Optionally clear filtered list
        this.machineName = ''; // Clear the input field
      },
      error: (err) => {
        console.error('Error removing machine:', err); // Handle error
      }
    });
  }


  clearForm() {
    this.newMachineName = '';
    this.newMachineLatitude = undefined;
    this.newMachineLongitude = undefined;
  }
}
