import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Machine } from '../machine/machine.model';

const graphqlUrl = 'http://localhost:4000/graphql'; // Define GraphQL URL here

interface GraphQLResponse {
  data: {
    machines: Machine[];
    addMachine: Machine;
    powerMachineOn: boolean;
    powerMachineOff: boolean;
    updatMachineLocation: boolean;
    turnIntoMaintenance: boolean;
    turnOutOfMaintenance: boolean;
    addIdentifiableMaterial: boolean;
    removeIdentifiableMaterial: boolean;
    removeMachine: string; // Add response for the remove machine mutation
  };
}

@Injectable({
  providedIn: 'root',
})
export class MachineService {
  getAll() {
    throw new Error('Method not implemented.');
  }
  constructor(private http: HttpClient) {}

  // Handle API errors and return them as observable errors
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    return throwError(() => new Error('Something went wrong. Please try again later.'));
  }

  // Get all machines via GraphQL query
  getMachines(): Observable<any> {
    const query = `query {
      getMachines {
        machine {
          id
          name
          powerStatus
          maintenanceStatus
          locationLatitude
          locationLongitude
          capacity
          orderId
        }
        identifiableMaterials {
          id
          name
          category
          machineId
        }
        sortedMaterials {
          id
          name
          status
          machineId
          sortedAt
          orderId
        }
      }
    }`;

    const payload = { query };

return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
  map((response) => {
    // Check if the 'response' has a valid 'data' and 'machines' field
    if (!response?.data || !response.data.machines) {
      console.error("Machine data is missing in the response");
      return []; // Return an empty array if machines data is missing
    }

    // Log the fetched data to ensure it's correctly returned
    console.log("Fetched data:", response.data.machines);

    // Return the machines data directly
    return response.data.machines;
  }),
  catchError(this.handleError) // Handle any errors from the HTTP request
);
  }




  create(data: {
    name: string;
    latitude: number;
    longitude: number;
    identifiableMaterialsList: { name: string; category: string }[];
  }): Observable<Machine> {
    const mutation = `
    mutation AddMachine($name: String!, $latitude: Float!, $longitude: Float!, $identifiableMaterialsList: [CriteriaMaterial!]!) {
      addMachine(name: $name, latitude: $latitude, longitude: $longitude, identifiableMaterialsList: $identifiableMaterialsList)
    }
  `;

    const payload = {
      query: mutation,
      variables: {
        name: data.name,
        latitude: data.latitude,
        longitude: data.longitude,
        identifiableMaterialsList: data.identifiableMaterialsList,
      },
    };

    return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
      map((response) => response.data.addMachine),
      catchError(this.handleError)
    );
  }


  removeMachine(machineId: string): Observable<string> {
    const mutation = `mutation RemoveMachine($machineId: String!) {
      removeMachine(machineId: $machineId)
    }`;

    const payload = {
      query: mutation,
      variables: { machineId },
    };

    return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
      map((response) => response.data.removeMachine),
      catchError(this.handleError)
    );
  }

  // Power on a machine
  powerOn(id: string): Observable<boolean> {
    const mutation = `mutation PowerOn($id: String!) {
      powerMachineOn(machineId: $id)
    }`;

    const payload = {
      query: mutation,
      variables: { id },
    };

    return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
      map((response) => response.data.powerMachineOn),
      catchError(this.handleError)
    );
  }

  // Power off a machine
  powerOff(id: string): Observable<boolean> {
    const mutation = `mutation PowerOff($id: String!) {
      powerMachineOff(machineId: $id)
    }`;

    const payload = {
      query: mutation,
      variables: { id },
    };

    return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
      map((response) => response.data.powerMachineOff),
      catchError(this.handleError)
    );
  }

  // Update machine location
  updateLocation(id: string, latitude: number, longitude: number): Observable<boolean> {
    const mutation = `mutation UpdateLocation($id: String!, $latitude: Float!, $longitude: Float!) {
      updatMachineLocation(machineId: $id, latitude: $latitude, longitude: $longitude)
    }`;

    const payload = {
      query: mutation,
      variables: { id, latitude, longitude },
    };

    return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
      map((response) => response.data.updatMachineLocation),
      catchError(this.handleError)
    );
  }

  // Toggle maintenance status of a machine
  toggleMaintenance(id: string, maintenanceStatus: boolean): Observable<boolean> {
    const mutation = maintenanceStatus
      ? `mutation TurnIntoMaintenance($id: String!) {
          turnIntoMaintenance(machineId: $id)
        }`
      : `mutation TurnOutOfMaintenance($id: String!) {
          turnOutOfMaintenance(machineId: $id)
        }`;

    const payload = {
      query: mutation,
      variables: { id },
    };

    return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
      map((response) => maintenanceStatus ? response.data.turnIntoMaintenance : response.data.turnOutOfMaintenance),
      catchError(this.handleError)
    );
  }

  // Add a material to a machine
  addMaterial(machineId: string, material: { name: string; category: string }): Observable<boolean> {
    const mutation = `mutation AddMaterial($machineId: String!, $material: CriteriaMaterialInput!) {
      addIdentifiableMaterial(machineId: $machineId, material: $material)
    }`;

    const payload = {
      query: mutation,
      variables: { machineId, material },
    };

    return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
      map((response) => response.data.addIdentifiableMaterial),
      catchError(this.handleError)
    );
  }

  // Remove a material from a machine
  removeMaterial(machineId: string, materialId: string): Observable<boolean> {
    const mutation = `mutation RemoveMaterial($machineId: String!, $materialId: String!) {
      removeIdentifiableMaterial(machineId: $machineId, materialId: $materialId)
    }`;

    const payload = {
      query: mutation,
      variables: { machineId, materialId },
    };

    return this.http.post<GraphQLResponse>(graphqlUrl, payload).pipe(
      map((response) => response.data.removeIdentifiableMaterial),
      catchError(this.handleError)
    );
  }
}
