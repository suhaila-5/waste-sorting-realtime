import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class NotificationAlertService {
  private baseUrl = 'http://localhost:4000/graphql'; // Replace with your GraphQL API URL

  constructor(private http: HttpClient) {}

  // Fetch notifications for a specific user by ID
  getNotifications(userId: string): Observable<any> {
    const query = `
      query {
        getNotifications(UserId: "${userId}") {
          id
          title
          message
          seen
          createdAt
        }
      }
    `;
    const payload = { query };
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(this.baseUrl, payload, { headers });
  }

  // Fetch all alerts
  getAlerts(): Observable<any> {
    const query = `
      query {
        getAlert {
          id
          title
          message
          createdAt
        }
      }
    `;
    const payload = { query };
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(this.baseUrl, payload, { headers });
  }
}
