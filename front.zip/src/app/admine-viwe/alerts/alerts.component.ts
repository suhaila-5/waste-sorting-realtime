import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationAlertService } from './alert.service';
import { NavbarComponent } from "../navbar/navbar.component";

@Component({
  selector: 'app-notifications-alerts',
  standalone: true,
  imports: [CommonModule, NavbarComponent],
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss'],
})
export class NotificationsAlertsComponent implements OnInit {
  notifications: any[] = [];
  alerts: any[] = [];
  error: string = '';
  loading: boolean = true;

  constructor(private notificationAlertService: NotificationAlertService) {}

  ngOnInit(): void {
    this.fetchNotifications('12345'); // Replace '12345' with a real user ID
    this.fetchAlerts();
  }

  // Fetch notifications for a user
  fetchNotifications(userId: string): void {
    this.notificationAlertService.getNotifications(userId).subscribe(
      (data) => {
        this.notifications = data.data.getNotifications;
        this.loading = false;
      },
      (err) => {
        console.error('Error fetching notifications:', err);
        this.error = 'Failed to fetch notifications.';
        this.loading = false;
      }
    );
  }

  // Fetch all alerts
  fetchAlerts(): void {
    this.notificationAlertService.getAlerts().subscribe(
      (data) => {
        this.alerts = data.data.getAlert;
        this.loading = false;
      },
      (err) => {
        console.error('Error fetching alerts:', err);
        this.error = 'Failed to fetch alerts.';
        this.loading = false;
      }
    );
  }
}
