import { Component, OnInit } from '@angular/core';
import { MachineService } from '../machine-management/machine.service';
import { Machine } from '../machine/machine.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from "../navbar/navbar.component";

@Component({
  selector: 'app-machine',
  templateUrl: './machine-viwe.component.html',
  styleUrls: ['./machine-viwe.component.scss'],
  imports: [CommonModule, FormsModule, NavbarComponent],
  standalone: true,
  providers: [MachineService],
})
export class MachineViweComponent implements OnInit {
  machines: Machine[] = [];
  loading: boolean = false;
  error: string = '';
  currentMachineId: string = ''; // Default to an empty string
  newMaterial: { name: string; category: string } = { name: '', category: '' };
  showAddMaterialFormFlag: boolean = false;

  constructor(private machineService: MachineService) {}

  ngOnInit(): void {
    this.fetchMachines();
  }

  private fetchMachines(): void {
    this.loading = true;
    this.machineService.getMachines().subscribe(
      (response) => {
        console.log('Fetched data:', response);
        this.machines = response.data.getMachines;
        this.loading = false;
      },
      (error) => {
        console.error('Error fetching machine data:', error);
        this.error = 'Failed to load machines.';
        this.loading = false;
      }
    );
  }

  // Power on a machine
  powerOn(id: string): void {
    this.machineService.powerOn(id).subscribe(
      (result) => {
        if (result) {
          this.fetchMachines();
          alert('Machine powered on!');
        }
      },
      (error) => {
        console.error('Error powering on machine:', error);
        alert('Failed to power on machine.');
      }
    );
  }

  // Power off a machine
  powerOff(id: string): void {
    this.machineService.powerOff(id).subscribe(
      (result) => {
        if (result) {
          this.fetchMachines();
          alert('Machine powered off!');
        }
      },
      (error) => {
        console.error('Error powering off machine:', error);
        alert('Failed to power off machine.');
      }
    );
  }

  // Toggle maintenance mode
  toggleMaintenance(id: string, status: boolean): void {
    this.machineService.toggleMaintenance(id, status).subscribe(
      (result) => {
        if (result) {
          this.fetchMachines();
          alert(status ? 'Machine is in maintenance.' : 'Machine is out of maintenance.');
        }
      },
      (error) => {
        console.error('Error toggling maintenance mode:', error);
        alert('Failed to toggle maintenance mode.');
      }
    );
  }

  // Show Add Material Form
  showAddMaterial(machine: Machine): void {
    this.currentMachineId = machine.id;
    this.showAddMaterialFormFlag = true;
    this.newMaterial = { name: '', category: '' };
  }

  // Cancel adding material
  cancelAddMaterial(): void {
    this.showAddMaterialFormFlag = false;
    this.currentMachineId = '',
    this.newMaterial = { name: '', category: '' };
  }

  // Add material to machine
  addMaterialToMachine(machineId: string, material: { name: string; category: string }): void {
    this.machineService.addMaterial(machineId, material).subscribe(
      (response) => {
        console.log('Material added:', response);
        this.fetchMachines();
        this.cancelAddMaterial();
      },
      (error) => {
        console.error('Error adding material:', error);
      }
    );
  }

  // Remove material from machine
  removeMaterialFromMachine(machineId: string, materialId: string): void {
    this.machineService.removeMaterial(machineId, materialId).subscribe(
      (response) => {
        console.log('Material removed:', response);
        this.fetchMachines();
      },
      (error) => {
        console.error('Error removing material:', error);
      }
    );
  }
}
