import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MachineViweComponent } from './machine-viwe.component';

describe('MachineViweComponent', () => {
  let component: MachineViweComponent;
  let fixture: ComponentFixture<MachineViweComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MachineViweComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MachineViweComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
