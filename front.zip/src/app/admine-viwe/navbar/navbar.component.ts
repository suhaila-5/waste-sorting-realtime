import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { ReportsComponent } from '../reports/reports.component';
import { MachineManagementComponent } from '../machine-management/machine-management.component';
import { MachineViweComponent } from '../machine-viwe/machine-viwe.component';
import { HttpClient } from '@angular/common/http';
import { NotificationsAlertsComponent } from '../alerts/alerts.component';

@Component({
  selector: 'app-navbar',
  standalone: true,
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  imports: [CommonModule, RouterLink, RouterLinkActive, MachineManagementComponent, MachineViweComponent, ReportsComponent,NotificationsAlertsComponent]
})
export class NavbarComponent implements OnInit {
  username: string = 'Guest'; // Default username
  private graphqlUrl = 'https://your-graphql-endpoint.com/graphql'; // Replace with your actual GraphQL API endpoint

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    const userEmail = this.getCurrentUserEmail(); // Replace with your logic to get the current user's email
    if (userEmail) {
      this.fetchUsername(userEmail);
    }
  }

  private getCurrentUserEmail(): string | null {
    // Replace this with your actual logic to retrieve the logged-in user's email
    return localStorage.getItem('userEmail'); // Example: Use localStorage for simplicity
  }

  private fetchUsername(email: string): void {
    const query = `
      query getUser($email: String!) {
        getUser(email: $email) {
          name
        }
      }
    `;

    const variables = {
      email: email,
    };

    this.http.post(this.graphqlUrl, { query, variables }).subscribe({
      next: (response: any) => {
        this.username = response?.data?.getUser?.name || 'Guest';
      },
      error: (err) => {
        console.error('Error fetching user:', err);
        this.username = 'Guest';
      },
    });
  }
}
