import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MachineService } from '../machine-management/machine.service';
import { NavbarComponent } from "../navbar/navbar.component";

@Component({
  selector: 'app-machine',
  standalone: true,
  imports: [CommonModule, FormsModule, NavbarComponent],
  templateUrl: './machine.component.html',
  styleUrls: ['./machine.component.scss'],
})

  export class MachineComponent {
    machine = {
      name: '',
      identifiableMaterialsList: [{ name: '', category: '' }],
      latitude: 0,  // Default to 0 instead of null
      longitude: 0, // Default to 0 instead of null
    };

    constructor(private machineService: MachineService) {}

    addMachine() {
      if (!this.machine.name || this.machine.latitude === null || this.machine.longitude === null) {
        alert('Please fill in all fields');
        return;
      }

      this.machineService.create(this.machine).subscribe({
        next: (response: any) => console.log('Add Machine Response:', response),
        error: (error) => {
          console.error('Error adding machine:', error);
          if (error.error && error.error.errors) {
            console.error('GraphQL Errors:', error.error.errors);
          } else {
            console.error('Error Details:', error);
          }
        },
      });
    }
  }



