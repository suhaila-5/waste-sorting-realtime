export interface Machine {
materials: any;
identifiableMaterials: any;
sortedMaterials: any;
longitude: any;
latitude: any;
  id: string;
  name: string;
  powerStatus: boolean;
  maintenanceStatus: boolean;
  locationLatitude: number;
  locationLongitude: number;
  capacity: number;
  orderId: number;
}
