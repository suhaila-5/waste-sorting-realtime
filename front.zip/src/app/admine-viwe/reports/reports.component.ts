import { CommonModule } from '@angular/common';
import { provideHttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { NavbarComponent } from "../navbar/navbar.component";

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, NavbarComponent],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent {
  onReportLoadError(reportType: string) {
    alert(`${reportType} report failed to load. Please try again later.`);
  }
  systemReportUrl: SafeResourceUrl='';
  machineReportUrl: SafeResourceUrl='';
  machineReportName: string='';

  constructor(private sanitizer: DomSanitizer) {}

  generateSystemReport() {
    // Replace with the actual URL of your system-wide Grafana dashboard
    const systemReportUrl = 'http://localhost:3000/goto/ZMDuyWIHg?orgId=1';
    this.systemReportUrl = this.sanitizer.bypassSecurityTrustResourceUrl(systemReportUrl);
  }

  generateMachineReport() {
    // Replace with the actual URL of your machine-specific Grafana dashboard
    const machineReportUrl = 'http://localhost:3000/goto/wdwXvjVHg?orgId=1';
    this.machineReportUrl = this.sanitizer.bypassSecurityTrustResourceUrl(machineReportUrl);
    this.machineReportName = 'Machine A'; // Replace with the actual machine name
  }
}
