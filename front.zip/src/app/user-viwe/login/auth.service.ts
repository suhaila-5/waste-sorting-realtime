import { jwtDecode } from 'jwt-decode';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root',

})
export class AuthService {
  private apiUrl = 'http://localhost:4000/graphql'; // Replace with your GraphQL API URL

  constructor(private http: HttpClient) {}

  // Utility function to decode a JWT
  private decodeToken(token: string): any {
    try {
      return jwtDecode(token);
    } catch (err) {
      console.error('Error decoding token', err);
      return null;
    }
  }

  signUp(name: string, email: string, password: string): Observable<any> {
    const query = `
      mutation {
        signUp(name: "${name}", email: "${email}", password: "${password}") {
          token
          user {
            id
            name
            email
          }
        }
      }
    `;

    return this.http.post<any>(this.apiUrl, { query });
  }

  login(email: string, password: string): Observable<any> {
    const query = `
      mutation {
        login(email: "${email}", password: "${password}") {
          token
          role
        }
      }
    `;

    return this.http.post<any>(this.apiUrl, { query });
  }

  getUser(email: string): Observable<any> {
    const query = `
      query {
        getUser(email: "${email}") {
          id
          name
          email
        }
      }
    `;

    return this.http.post<any>(this.apiUrl, { query });
  }

  getAdmin(email: string): Observable<any> {
    const query = `
      query {
        getAdmin(email: "${email}") {
          id
          name
          email
        }
      }
    `;

    return this.http.post<any>(this.apiUrl, { query });
  }

  getNotifications(userId: string): Observable<any> {
    const query = `
      query {
        getNotifications(UserId: "${userId}") {
          id
          title
          message
          seen
        }
      }
    `;

    return this.http.post<any>(this.apiUrl, { query });
  }

  resetPassword(email: string, password: string, newPassword: string, isAdmin = false): Observable<any> {
    const mutationName = isAdmin ? 'AdminResetPassword' : 'UserResetPassword';
    const query = `
      mutation {
        ${mutationName}(email: "${email}", password: "${password}", newPassword: "${newPassword}")
      }
    `;

    return this.http.post<any>(this.apiUrl, { query });
  }

  // Token-based methods for client-side management
  saveToken(token: string): void {
    localStorage.setItem('auth_token', token);
  }

  getToken(): string | null {
    return localStorage.getItem('auth_token');
  }

  clearToken(): void {
    localStorage.removeItem('auth_token');
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) return false;

    const decoded = this.decodeToken(token);
    return decoded && decoded.exp > Date.now() / 1000;
  }
}
