import { Routes } from '@angular/router';
import { ReportsComponent } from './admine-viwe/reports/reports.component';
import { MachineComponent } from './admine-viwe/machine/machine.component';
import { MachineManagementComponent } from './admine-viwe/machine-management/machine-management.component';
import { MachineViweComponent } from './admine-viwe/machine-viwe/machine-viwe.component';
import { NotificationsAlertsComponent } from './admine-viwe/alerts/alerts.component';

export const routes: Routes = [
  { path: 'reports', component: ReportsComponent },
  { path: 'machine', component: MachineComponent },
  { path: 'machine-management', component: MachineManagementComponent },
  { path: 'machine-Viwe', component: MachineViweComponent },
  { path: 'alerts', component: NotificationsAlertsComponent },
  { path: '**', redirectTo: '/machine-management' },
  { path: '', redirectTo: '/machine-management', pathMatch: 'full' },

];
