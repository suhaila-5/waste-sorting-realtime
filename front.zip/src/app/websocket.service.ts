// websocket.service.ts
import { Injectable } from '@angular/core';
import { webSocket } from 'rxjs/webSocket';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WebSocketService {
  private socket$;
  private messagesSubject = new Subject<string>();

  constructor() {
    // Initialize the WebSocket connection
    this.socket$ = webSocket('ws://localhost:3500'); // Replace with your WebSocket server URL
  }

  // Send a message to the WebSocket server
  sendMessage(message: string): void {
    this.socket$.next(message);
  }

  // Receive messages from the WebSocket server
  getMessages() {
    return this.socket$.asObservable();
  }

  // Close the WebSocket connection
  closeConnection() {
    this.socket$.complete();
  }
}
