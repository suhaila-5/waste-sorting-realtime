import { Injectable } from '@angular/core';
import { ApolloClient, InMemoryCache, HttpLink } from '@apollo/client/core';
import { Apollo } from 'apollo-angular';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root', // makes it globally available
})
export class ApolloService {
  private apolloClient: ApolloClient<any>;

  constructor(private httpLink: HttpLink) {
    // Create Apollo Client instance
    this.apolloClient = new ApolloClient({
      link: httpLink.create({ uri: 'http://localhost:4000/graphql' }), // Replace with your GraphQL endpoint
      cache: new InMemoryCache(),
    });
  }

  // Example method to fetch data from GraphQL API
  fetchData(query: string): Observable<any> {
    return this.apolloClient.query({
      query: query,
    }).then(response => response.data); // Adjust according to your data structure
  }
}
