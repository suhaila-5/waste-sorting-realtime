module.exports = (sequelize, DataTypes) => {
  const sortedMaterial = sequelize.define("SortedMaterial", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("recycled", "non-recycled"),
      allowNull: false,
    },
    sortedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    orderId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  });

  sortedMaterial.associate = (models) => {
    sortedMaterial.belongsTo(models.Machine, {
      foreignKey: "machineId",
      onDelete: "CASCADE",
      as: "Machine",
    });
  };

  return sortedMaterial;
};
