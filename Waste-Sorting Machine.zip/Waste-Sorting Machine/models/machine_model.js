module.exports = (sequelize, DataTypes) => {
  const machine = sequelize.define("Machine", {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: DataTypes.UUIDV4,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    powerStatus: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
    maintenanceStatus: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
    orderId: {
      type : DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1,
    },
    capacity: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 500,
    },
    locationLongitude: {
      type: DataTypes.DECIMAL(10, 6),
      allowNull: false,
    },
    locationLatitude: {
      type: DataTypes.DECIMAL(10, 6),
      allowNull: false,
    },
  });

  machine.associate = (models) => {
    machine.hasMany(models.IdentifiableMaterial, {
      foreignKey: "machineId",
      as: "IdentifiableMaterials",
    });
    machine.hasMany(models.SortedMaterial, {
      foreignKey: "machineId",
      as: "SortedMaterials",
    });
  };

  return machine;
};
