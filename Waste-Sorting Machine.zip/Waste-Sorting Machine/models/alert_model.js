module.exports = (sequelize, DataTypes) => {
    const alert = sequelize.define('Alert', {
        id: {
            type: DataTypes.UUID,
            primaryKey: true,
            defaultValue: DataTypes.UUIDV4,
        },
        title: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        message: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        machineId: {
            type: DataTypes.UUID,
            references: {
                model: 'Machines',
                key: 'id',
            },
            allowNull: false,
        },
    });

    alert.associate = (model) => {
        alert.belongsTo(model.Machine, {
            foreignKey: 'machineId',
            onDelete: 'CASCADE',
            as: 'Machine',
        });
    }

    return alert;
}