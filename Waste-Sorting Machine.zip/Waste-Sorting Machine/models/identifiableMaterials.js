module.exports = (sequelize, DataTypes) => {
    const identifiableMaterial = sequelize.define("IdentifiableMaterial", {
      id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: DataTypes.UUIDV4,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      category: {
        type: DataTypes.ENUM("recyclable", "non-recyclable"),
        allowNull: false,
      },
    });
  
    identifiableMaterial.associate = (models) => {
      identifiableMaterial.belongsTo(models.Machine, {
        foreignKey: "machineId",
        onDelete: "CASCADE",
        as: "Machine",
      });
    };
  
    return identifiableMaterial;
  };
  