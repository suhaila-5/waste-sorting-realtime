module.exports = (sequelize, DataTypes) => {
  const notification = sequelize.define("Notification", {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: DataTypes.UUIDV4,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    message: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    seen: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    userId: {
      type: DataTypes.UUID,
      references: {
        model: "Users",
        key: "id",
      },
      allowNull: false,
    },
    machineId: {
      type: DataTypes.UUID,
      references: {
        model: "Machines",
        key: "id",
      },
      allowNull: false,
    },
  });

  notification.associate = (models) => {
    notification.belongsTo(models.User, {
      foreignKey: "userId",
      onDelete: "CASCADE",
      as: "User",
    });
    notification.belongsTo(models.Machine, {
      foreignKey: "machineId",
      onDelete: "CASCADE",
      as: "Machine",
    });
  };

  return notification;
};
