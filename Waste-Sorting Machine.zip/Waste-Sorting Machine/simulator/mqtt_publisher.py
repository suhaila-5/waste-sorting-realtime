import paho.mqtt.client as mqtt
import random
import time
import requests 

def get_machine_ids():
    query = """
    query {
      getMachines {
        machine {
          id
        }
      }
    }
    """
    url = "http://localhost:4000/graphql"
    response = requests.post(url, json={"query": query})
    data = response.json()
    if 'data' in data and 'getMachines' in data['data']:
        return [machine['machine']['id'] for machine in data['data']['getMachines']]
    else:
        print("Failed to fetch machine IDs. Response:", data)
        return []

broker = "localhost"
port = 1883
topic = "waste/sorting"
materials = ["plastic bottles", "aluminum cans", "newspapers", "cotton", "spoiled food", "fruit peels", "straws"]

material_categories = {
    "plastic bottles": "recyclable", #plastic
    "aluminum cans": "recyclable",#metal
    "newspapers": "recyclable",#paper
    "cotton": "recyclable",#textile
    "spoiled food": "non-recyclable",#food waste
    "fruit peels": "non-recyclable",#food waste
    "straws": "non-recyclable",#straws
}

client = mqtt.Client()
client.connect(broker, port, 60)

try:
    machine_ids = get_machine_ids()
    if not machine_ids:
        raise Exception("No machine IDs available to publish messages.")

    while True:
        material = random.choice(materials)
        category = material_categories[material]
        machine_id = random.choice(machine_ids)
        message = f"{material}|{category}|{machine_id}"
        print(f"Publishing: {message}")
        client.publish(topic, message)
        time.sleep(2)
except KeyboardInterrupt:
    print("Stopped by user")
    client.disconnect()
except Exception as e:
    print("Error:", str(e))
