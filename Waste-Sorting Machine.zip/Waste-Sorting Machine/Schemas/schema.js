const redis = require("../redis");
const {
  GraphQLObjectType,
  GraphQLSchema,
  GraphQLString,
  GraphQLNonNull,
  GraphQLList,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLFloat,
} = require("graphql");

const db = require("../models");
const {
  Sequelize,
  User,
  Admin,
  Machine,
  IdentifiableMaterial,
  SortedMaterial,
  Notification,
  Alert,
} = db;
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const secret = require("../config/jwt.config");
const {
  UserType,
  AdminType,
  logInAuthPayload,
  UserAuthPayload,
  AdminAuthPayload,
  MachineType,
  IdentifiableMaterialType,
  SortedMaterialType,
  CriteriaMaterialType,
  AssignedMaterialType,
  RetrieveMachineType,
  validatMaterialsResponseType,
  SortedMaterialResponseType,
  notificationType,
  alertType,
  reportMachineType,
  reportMachinesType,
} = require("./types");

const RootQuery = new GraphQLObjectType({
  name: "RootQuery",
  fields: {
    getUser: {
      type: UserType,
      args: {
        email: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { email }) => {
        try {
          const cacheKey = `user:${email}`;
          const cachedUser = await redis.get(cacheKey);
          if (cachedUser) {
            console.log("Cache hit: User found in Redis.");
            return JSON.parse(cachedUser);
          }
          const user = await User.findOne({ where: { email: email } });
          if (!user) {
            throw new Error("User not found");
          }
          await redis.setex(cacheKey, 5400, JSON.stringify(user));
          return user;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving user"
          );
        }
      },
    },
    getAdmin: {
      type: AdminType,
      args: {
        email: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { email }) => {
        try {
          const cacheKey = `admin:${email}`;
          const cachedAdmin = await redis.get(cacheKey);
          if (cachedAdmin) {
            console.log("Cache hit: Admin found in Redis.");
            return JSON.parse(cachedAdmin);
          }
          const admin = await Admin.findOne({ where: { email: email } });
          if (!admin) {
            throw new Error("User not found");
          }
          await redis.setex(cacheKey, 5400, JSON.stringify(admin));
          return admin;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving admin"
          );
        }
      },
    },
    getNotifications: {
      type: new GraphQLNonNull(GraphQLList(notificationType)),
      args: {
        UserId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { UserId }) => {
        try {
          const user = await User.findByPk(UserId);
          if (!user) {
            throw new Error("User not found");
          }
          const notifications = await Notification.findAll({
            where: { userId: UserId },
          });
          return notifications;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while fetching notifications"
          );
        }
      },
    },
    getAlert: {
      type: new GraphQLNonNull(GraphQLList(alertType)),
      resolve: async (_) => {
        try {
          const alerts = await Alert.findAll();
          return alerts;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while fetching alerts"
          );
        }
      },
    },
    getMachine: {
      type: RetrieveMachineType,
      args: {
        id: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { id }) => {
        try {
          const cacheKey = `machine:${id}`;
          const cachedMachine = await redis.get(cacheKey);
          if (cachedMachine) {
            console.log("Cache hit: Machine found in Redis.");
            return JSON.parse(cachedMachine);
          }
          const machine = await Machine.findByPk(id, {
            include: [
              {
                model: IdentifiableMaterial,
                as: "IdentifiableMaterials",
              },
              {
                model: SortedMaterial,
                as: "SortedMaterials",
              },
            ],
          });
          if (!machine) {
            throw new Error("Machine not found");
          }
          const machineData = {
            machine,
            identifiableMaterials: machine.IdentifiableMaterials,
            sortedMaterials: machine.SortedMaterials,
          };
          await redis.setex(cacheKey, 5400, JSON.stringify(machineData));
          return machineData;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving machine"
          );
        }
      },
    },
    getMachineByName: {
      type: new GraphQLNonNull(GraphQLList(MachineType)),
      args: {
        name: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { name }) => {
        try {
          const cacheKey = `machineByName:${name}`;
          const cachedMachines = await redis.get(cacheKey);
          if (cachedMachines) {
            console.log("Cache hit: Machines found in Redis.");
            return JSON.parse(cachedMachines);
          }
          const machine = await Machine.findAll({ where: { name: name } });
          if (!machine) {
            throw new Error("Machine not found");
          }
          await redis.setex(cacheKey, 5400, JSON.stringify(machine));
          return machine;
        } catch (err) {
          throw new Error(
            err.message ||
              "Some error occurred while retrieving machine by name"
          );
        }
      },
    },
    getMachines: {
      type: new GraphQLNonNull(GraphQLList(RetrieveMachineType)),
      resolve: async () => {
        try {
          const cacheKey = "machines";
          const cachedMachines = await redis.get(cacheKey);
          if (cachedMachines) {
            console.log("Cache hit: Machines found in Redis.");
            return JSON.parse(cachedMachines);
          }
          const machineList = await Machine.findAll({
            include: [
              {
                model: IdentifiableMaterial,
                as: "IdentifiableMaterials",
              },
              {
                model: SortedMaterial,
                as: "SortedMaterials",
              },
            ],
          });
          const machineDataList = machineList.map((machine) => ({
            machine: machine,
            identifiableMaterials: machine.IdentifiableMaterials,
            sortedMaterials: machine.SortedMaterials,
          }));
          await redis.setex(cacheKey, 5400, JSON.stringify(machineDataList));
          return machineDataList;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving machines"
          );
        }
      },
    },
    getMaterialsName: {
      type: new GraphQLList(GraphQLString),
      resolve: async () => {
        try {
          const cacheKey = "materialsName";
          const cachedMaterials = await redis.get(cacheKey);
          if (cachedMaterials) {
            console.log("Cache hit: Materials name found in Redis.");
            return JSON.parse(cachedMaterials);
          }
          console.log("IdentifiableMaterial model:", IdentifiableMaterial);
          const materials = await IdentifiableMaterial.findAll({
            attributes: [
              [Sequelize.fn("DISTINCT", Sequelize.col("name")), "name"],
            ],
          });
          const materialNames = materials.map((material) => material.name);
          await redis.setex(cacheKey, 5400, JSON.stringify(materialNames));
          return materialNames;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving"
          );
        }
      },
    },
    getIdentifiableMaterials: {
      type: new GraphQLList(IdentifiableMaterialType),
      resolve: async () => {
        try {
          const cacheKey = "identifiableMaterials";
          const cachedMaterials = await redis.get(cacheKey);
          if (cachedMaterials) {
            console.log("Cache hit: Identifiable materials found in Redis.");
            return JSON.parse(cachedMaterials);
          }
          const materials = await IdentifiableMaterial.findAll();
          await redis.setex(cacheKey, 5400, JSON.stringify(materials));
          return materials;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving materials"
          );
        }
      },
    },
    getMachineIdentifiableMaterials: {
      type: new GraphQLList(IdentifiableMaterialType),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `machine:${machineId}:identifiableMaterials`;
          const cachedMaterials = await redis.get(cacheKey);
          if (cachedMaterials) {
            console.log(
              "Cache hit: Identifiable materials for machine found in Redis."
            );
            return JSON.parse(cachedMaterials);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const materials = await IdentifiableMaterial.findAll({
            where: { machineId: machineId },
          });
          await redis.setex(cacheKey, 5400, JSON.stringify(materials));
          return materials;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving materials"
          );
        }
      },
    },
    getMachineRecyclMaterials: {
      type: new GraphQLList(SortedMaterialType),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `machine:${machineId}:recycledMaterials`;
          const cachedMaterials = await redis.get(cacheKey);
          if (cachedMaterials) {
            console.log(
              "Cache hit: Recycled materials for machine found in Redis."
            );
            return JSON.parse(cachedMaterials);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const materials = await SortedMaterial.findAll({
            where: { machineId: machineId, status: "recycled" },
          });
          await redis.setex(cacheKey, 5400, JSON.stringify(materials));
          return materials;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving materials"
          );
        }
      },
    },
    getMachineNonRecyclMaterials: {
      type: new GraphQLList(SortedMaterialType),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `machine:${machineId}:nonRecycledMaterials`;
          const cachedMaterials = await redis.get(cacheKey);
          if (cachedMaterials) {
            console.log(
              "Cache hit: Non-recycled materials for machine found in Redis."
            );
            return JSON.parse(cachedMaterials);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const materials = await SortedMaterial.findAll({
            where: { machineId: machineId, status: "non-recycled" },
          });
          await redis.setex(cacheKey, 5400, JSON.stringify(materials));
          return materials;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving materials"
          );
        }
      },
    },
    getMachineSortedMaterials: {
      type: new GraphQLList(SortedMaterialType),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `machine:${machineId}:sortedMaterials`;
          const cachedMaterials = await redis.get(cacheKey);
          if (cachedMaterials) {
            console.log(
              "Cache hit: Sorted materials for machine found in Redis."
            );
            return JSON.parse(cachedMaterials);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const materials = await SortedMaterial.findAll({
            where: { machineId: machineId },
          });
          await redis.setex(cacheKey, 5400, JSON.stringify(materials));
          return materials;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving materials"
          );
        }
      },
    },
    monitorMachineState: {
      type: new GraphQLNonNull(MachineType),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `machine:${machineId}:state`;
          const cachedMachine = await redis.get(cacheKey);
          if (cachedMachine) {
            console.log("Cache hit: Machine state found in Redis.");
            return JSON.parse(cachedMachine);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          await redis.setex(cacheKey, 5400, JSON.stringify(machine));
          return machine;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while retrieving machine state"
          );
        }
      },
    },
    viewSortedMaterialsCount: {
      type: new GraphQLNonNull(GraphQLInt),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `machine:${machineId}:sortedMaterialsCount`;
          const cachedCount = await redis.get(cacheKey);
          if (cachedCount) {
            console.log("Cache hit: Sorted materials count found in Redis.");
            return parseInt(cachedCount, 10);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const sortedMaterialsCount = await SortedMaterial.count({
            where: { machineId: machineId },
          });
          await redis.setex(cacheKey, 5400, sortedMaterialsCount.toString());
          return sortedMaterialsCount;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while counting sorted materials"
          );
        }
      },
    },
    viewRecycledSortedMaterialsCount: {
      type: new GraphQLNonNull(GraphQLInt),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `recycledSortedMaterialsCount:${machineId}`;
          const cachedCount = await redis.get(cacheKey);
          if (cachedCount) {
            console.log(
              "Cache hit: Recycled sorted materials count found in Redis."
            );
            return parseInt(cachedCount, 10);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const recycledSortedMaterialsCount = await SortedMaterial.count({
            where: { machineId: machineId, status: "recycled" },
          });
          await redis.setex(cacheKey, 5400, recycledSortedMaterialsCount);
          return recycledSortedMaterialsCount;
        } catch (err) {
          throw new Error(
            err.message ||
              "Some error occurred while counting recycled sorted materials"
          );
        }
      },
    },
    viewNonRecycledSortedMaterialsCount: {
      type: new GraphQLNonNull(GraphQLInt),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `nonRecycledSortedMaterialsCount:${machineId}`;
          const cachedCount = await redis.get(cacheKey);
          if (cachedCount) {
            console.log(
              "Cache hit: Non-recycled sorted materials count found in Redis."
            );
            return parseInt(cachedCount, 10);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const nonRecycledSortedMaterialsCount = await SortedMaterial.count({
            where: { machineId: machineId, status: "non-recycled" },
          });
          await redis.setex(cacheKey, 5400, nonRecycledSortedMaterialsCount);
          return nonRecycledSortedMaterialsCount;
        } catch (err) {
          throw new Error(
            err.message ||
              "Some error occurred while counting non-recycled sorted materials"
          );
        }
      },
    },
    reportMachine: {
      type: reportMachineType,
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const cacheKey = `reportMachine:${machineId}`;
          const cachedReport = await redis.get(cacheKey);
          if (cachedReport) {
            console.log("Cache hit: Report found in Redis.");
            return JSON.parse(cachedReport);
          }
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const identifiableMaterialsCount = await IdentifiableMaterial.count({
            where: { machineId: machineId },
          });
          const sortedMaterialsCount = await SortedMaterial.count({
            where: { machineId: machineId },
          });
          const recycledSortedMaterialsCount = await SortedMaterial.count({
            where: { machineId: machineId, status: "recycled" },
          });
          const nonRecycledSortedMaterialsCount = await SortedMaterial.count({
            where: { machineId: machineId, status: "non-recycled" },
          });
          const reportData = {
            machineId: machine.id,
            machineName: machine.name,
            powerStatus: machine.powerStatus,
            maintenanceStatus: machine.maintenanceStatus,
            capacity: machine.capacity,
            machineLocation: [
              machine.locationLongitude,
              machine.locationLatitude,
            ],
            totalOrders: machine.orderId,
            totalIdentifiableMaterials: identifiableMaterialsCount,
            totalSortedMaterials: sortedMaterialsCount,
            totalRecycledMaterials: recycledSortedMaterialsCount,
            totalNonRecycledMaterials: nonRecycledSortedMaterialsCount,
          };
          await redis.setex(cacheKey, 5400, JSON.stringify(reportData));
          return reportData;
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while generating report"
          );
        }
      },
    },
  },
});

const Mutation = new GraphQLObjectType({
  name: "Mutation",
  fields: {
    addAdmin: {
      type: AdminAuthPayload,
      args: {
        name: { type: new GraphQLNonNull(GraphQLString) },
        email: { type: new GraphQLNonNull(GraphQLString) },
        password: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { name, email, password }) => {
        try {
          const exisitingAdmin = await Admin.findOne({
            where: { email: email },
          });
          if (exisitingAdmin) {
            throw new Error("Admin already exists");
          }
          const hashedPassword = await bcrypt.hash(password, 10);
          const admin = await Admin.create({
            name: name,
            email: email,
            password: hashedPassword,
          });
          const token = jwt.sign({ id: admin.id }, secret.secret, {
            expiresIn: "1h",
          });
          return { token, admin };
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while adding admin"
          );
        }
      },
    },
    deleteAdmin: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        id: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { id }) => {
        try {
          const admin = await Admin.findByPk(id);
          if (!admin) {
            throw new Error("Admin not found");
          }
          await admin.destroy();
          await redis.del(`admin:${admin.email}`);
          return "Admin deleted successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while deleting admin"
          );
        }
      },
    },
    deleteUser: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        id: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { id }) => {
        try {
          const user = await User.findByPk(id);
          if (!user) {
            throw new Error("User not found");
          }
          await user.destroy();
          await redis.del(`user:${user.email}`);
          return "User deleted successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while deleting user"
          );
        }
      },
    },
    signUp: {
      type: new GraphQLNonNull(UserAuthPayload),
      args: {
        name: { type: new GraphQLNonNull(GraphQLString) },
        email: { type: new GraphQLNonNull(GraphQLString) },
        password: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { name, email, password }) => {
        try {
          console.log("User model:", User);
          const exisitingUser = await User.findOne({ where: { email: email } });
          if (exisitingUser) {
            throw new Error("User already exists");
          }

          const hashedPassword = await bcrypt.hash(password, 10);

          const user = await User.create({
            name: name,
            email: email,
            password: hashedPassword,
          });

          const token = jwt.sign({ id: user.id }, secret.secret, {
            expiresIn: "1h",
          });

          return { token, user };
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while signing up"
          );
        }
      },
    },
    login: {
      type: new GraphQLNonNull(logInAuthPayload),
      args: {
        email: { type: new GraphQLNonNull(GraphQLString) },
        password: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { email, password }) => {
        try {
          const user = await User.findOne({ where: { email: email } });
          const admin = await Admin.findOne({ where: { email: email } });
          if (!user && !admin) {
            throw new Error("User not registered");
          } else {
            if (!admin) {
              const isMatch = await bcrypt.compare(password, user.password);
              if (!isMatch) {
                throw new Error("Invalid password");
              }
              const token = jwt.sign({ id: user.id }, secret.secret, {
                expiresIn: "1h",
              });

              return { token, role: user.role };
            } else {
              const isMatch = await bcrypt.compare(password, admin.password);
              if (!isMatch) {
                throw new Error("Invalid password");
              }
              const token = jwt.sign({ id: admin.id }, secret.secret, {
                expiresIn: "1h",
              });
              return { token, role: admin.role };
            }
          }
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while logging in"
          );
        }
      },
    },
    UserResetPassword: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        email: { type: new GraphQLNonNull(GraphQLString) },
        password: { type: new GraphQLNonNull(GraphQLString) },
        newPassword: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { email, password, newPassword }) => {
        try {
          const user = await User.findOne({ where: { email: email } });
          if (!user) {
            throw new Error("User not found");
          }
          const isMatch = await bcrypt.compare(password, user.password);
          if (!isMatch) {
            throw new Error("Invalid password");
          }
          const hashedPassword = await bcrypt.hash(newPassword, 10);
          await user.update({ password: hashedPassword });
          await redis.del(`user:${email}`);
          return "Password reset successful";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while resetting password"
          );
        }
      },
    },
    AdminResetPassword: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        email: { type: new GraphQLNonNull(GraphQLString) },
        password: { type: new GraphQLNonNull(GraphQLString) },
        newPassword: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { email, password, newPassword }) => {
        try {
          const admin = await Admin.findOne({ where: { email: email } });
          if (!admin) {
            throw new Error("admin not found");
          }
          const isMatch = await bcrypt.compare(password, admin.password);
          if (!isMatch) {
            throw new Error("Invalid password");
          }
          const hashedPassword = await bcrypt.hash(newPassword, 10);
          await admin.update({ password: hashedPassword });
          await redis.del(`admin:${email}`);
          return "Password reset successful";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while resetting password"
          );
        }
      },
    },
    addMachine: {
      type: GraphQLString,
      args: {
        name: { type: new GraphQLNonNull(GraphQLString) },
        identifiableMaterialsList: {
          type: new GraphQLNonNull(
            new GraphQLList(new GraphQLNonNull(CriteriaMaterialType))
          ),
        },
        latitude: { type: new GraphQLNonNull(GraphQLFloat) },
        longitude: { type: new GraphQLNonNull(GraphQLFloat) },
      },
      resolve: async (
        _,
        { name, identifiableMaterialsList, latitude, longitude }
      ) => {
        try {
          const machine = await Machine.create({
            name: name,
            powerStatus: true,
            maintenanceStatus: false,
            locationLongitude: longitude,
            locationLatitude: latitude,
          });
          const materialList = await IdentifiableMaterial.bulkCreate(
            identifiableMaterialsList.map((material) => ({
              name: material.name,
              category: material.category,
              machineId: machine.id,
            })),
            { returning: true }
          );
          await redis.del("machines");
          // return {machine, materialList};
          return "Added Machine successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while adding machine"
          );
        }
      },
    },
    removeMachine: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          await IdentifiableMaterial.destroy({
            where: { machineId: machineId },
          });
          await SortedMaterial.destroy({ where: { machineId: machineId } });
          await machine.destroy({ where: { machineId } });
          await redis.del(`machine:${machineId}:identifiableMaterials`);
          await redis.del(`machine:${machineId}:sortedMaterials`);
          await redis.del(`machine:${machineId}:recycledMaterials`);
          await redis.del(`machine:${machineId}:nonRecycledMaterials`);
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Machine removed successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while removing machine"
          );
        }
      },
    },
    updateMachineName: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
        name: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId, name }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          await Machine.update({ name: name }, { where: { id: machineId } });
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Machine name updated successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while updating machine name"
          );
        }
      },
    },
    updatMachineLocation: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
        latitude: { type: new GraphQLNonNull(GraphQLFloat) },
        longitude: { type: new GraphQLNonNull(GraphQLFloat) },
      },
      resolve: async (_, { machineId, latitude, longitude }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          await Machine.update(
            { locationLatitude: latitude, locationLongitude: longitude },
            { where: { id: machineId } }
          );
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Machine location updated successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while updating machine location"
          );
        }
      },
    },
    powerMachineOn: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          if (machine.powerStatus) {
            return "Machine is already on";
          }
          await machine.update({ powerStatus: true });
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Machine powered on successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while powering machine on"
          );
        }
      },
    },
    powerMachineOff: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          if (!machine.powerStatus) {
            return "Machine is already off";
          }
          await machine.update({ powerStatus: false });
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Machine powered off successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while powering machine off"
          );
        }
      },
    },
    turnIntoMaintenance: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          if (machine.maintenanceStatus) {
            return "Machine is already in maintenance";
          }
          await Machine.update(
            {
              maintenanceStatus: true,
              orderId: machine.orderId + 1,
              capacity: 500,
            },
            { where: { id: machineId } }
          );
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Machine turned into maintenance successfully";
        } catch (err) {
          throw new Error(
            err.message ||
              "Some error occurred while turning machine into maintenance"
          );
        }
      },
    },
    turnOutOfMaintenance: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          if (!machine.maintenanceStatus) {
            return "Machine is not in maintenance";
          }
          await machine.update({ maintenanceStatus: false });
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Machine turned out of maintenance successfully";
        } catch (err) {
          throw new Error(
            err.message ||
              "Some error occurred while turning machine out of maintenance"
          );
        }
      },
    },
    addIdentifiableMaterial: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
        material: { type: new GraphQLNonNull(CriteriaMaterialType) },
      },
      resolve: async (_, { machineId, material }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const exisitMateria = await IdentifiableMaterial.findAll({
            where: { machineId: machineId, name: material.name },
          });
          if (exisitMateria.length > 0) {
            throw new Error("Material already exists");
          }
          const newMaterial = await IdentifiableMaterial.create({
            name: material.name,
            category: material.category,
            machineId: machineId,
          });
          await redis.del(`machine:${machineId}:identifiableMaterials`);
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Material added successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while adding material"
          );
        }
      },
    },
    removeIdentifiableMaterial: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
        materialId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId, materialId }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          const material = await IdentifiableMaterial.findByPk(materialId);
          if (!material) {
            throw new Error("Material not found");
          }
          await material.destroy();
          await redis.del(`machine:${machineId}:identifiableMaterials`);
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Material removed successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while removing material"
          );
        }
      },
    },
    updateIdentifiableMaterial: {
      type: new GraphQLNonNull(GraphQLString),
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
        materialId: { type: new GraphQLNonNull(GraphQLString) },
        material: { type: CriteriaMaterialType },
      },
      resolve: async (_, { machineId, materialId, material }) => {
        try {
          const existMachine = await Machine.findByPk(machineId);
          if (!existMachine) {
            throw new Error("Machine not found");
          }
          const existMaterial = await IdentifiableMaterial.findByPk(materialId);
          if (!existMaterial) {
            throw new Error("Material not found");
          }
          await IdentifiableMaterial.update(
            { name: material.name, category: material.category },
            { where: { id: materialId } }
          );
          await redis.del(`machine:${machineId}:identifiableMaterials`);
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return "Material updated successfully";
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while updating material"
          );
        }
      },
    },
    validateMaterials: {
      type: validatMaterialsResponseType,
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
        materials: {
          type: new GraphQLNonNull(new GraphQLList(AssignedMaterialType)),
        },
      },
      resolve: async (_, { machineId, materials }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          if (!machine.powerStatus || machine.maintenanceStatus) {
            Alert.create({
              title: "Error",
              message: "Machine is not in operation",
              machineId: machineId,
            });
            throw new Error("Machine is not in operation");
          }
          const identifiableMaterials = await IdentifiableMaterial.findAll({
            where: { machineId: machineId },
          });
          const validatedMaterials = [];
          const invalidMaterials = [];
          for (const material of materials) {
            const existMaterial = identifiableMaterials.find(
              (item) => item.name === material.name
            );
            if (existMaterial) {
              validatedMaterials.push({
                name: existMaterial.name,
                category: existMaterial.category,
              });
            } else {
              invalidMaterials.push(material.name);
            }
          }
          return { validatedMaterials, invalidMaterials };
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while validating materials"
          );
        }
      },
    },
    sortMaterial: {
      type: SortedMaterialResponseType,
      args: {
        machineId: { type: new GraphQLNonNull(GraphQLString) },
        materials: {
          type: new GraphQLNonNull(GraphQLList(CriteriaMaterialType)),
        },
        userId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { machineId, materials, userId }) => {
        try {
          const machine = await Machine.findByPk(machineId);
          if (!machine) {
            throw new Error("Machine not found");
          }
          if (materials.length > machine.capacity) {
            await Alert.create({
              title: "Error",
              message: "Capacity exceeded",
              machineId: machineId,
            });
            throw new Error("Machine capacity exceeded");
          }
          if (!machine.powerStatus || machine.maintenanceStatus) {
            await Alert.create({
              title: "Error",
              message: "Machine is not in operation",
              machineId: machineId,
            });
            throw new Error("Machine is not in operation");
          }
          await machine.update({
            capacity: machine.capacity - materials.length,
          });
          const recycledMaterials = [];
          const nonRecycledMaterials = [];
          for (const material of materials) {
            if (material.category === "recyclable") {
              await SortedMaterial.create({
                name: material.name,
                status: "recycled",
                machineId: machineId,
                orderId: machine.orderId,
              });
              recycledMaterials.push({
                name: material.name,
                category: material.category,
              });
            } else {
              await SortedMaterial.create({
                name: material.name,
                status: "non-recycled",
                machineId: machineId,
                orderId: machine.orderId,
              });
              nonRecycledMaterials.push({
                name: material.name,
                category: material.category,
              });
            }
          }
          const notification = await Notification.create({
            title: "Sorting Process",
            message: "Materials have been sorted successfully",
            machineId: machineId,
            userId: userId,
          });
          await redis.del(`machine:${machineId}:sortedMaterials`);
          await redis.del(`machine:${machineId}:recycledMaterials`);
          await redis.del(`machine:${machineId}:nonRecycledMaterials`);
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");
          return { notification, recycledMaterials, nonRecycledMaterials };
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while sorting materials"
          );
        }
      },
    },

    addMaterialFromMQTT: {
      type: SortedMaterialResponseType,
      args: {
        materialName: { type: new GraphQLNonNull(GraphQLString) },
        category: { type: new GraphQLNonNull(GraphQLString) },
        machineId: { type: new GraphQLNonNull(GraphQLString) },
      },
      resolve: async (_, { materialName, category, machineId }) => {
        try {
          console.log("Category received:", category);
          const machine = await Machine.findByPk(machineId, {
            include: [
              {
                model: IdentifiableMaterial,
                as: "IdentifiableMaterials",
              },
            ],
          });
          if (!machine) {
            throw new Error("Machine not found");
          }
          const identifiableMaterial = machine.IdentifiableMaterials.find(
            (item) => item.name === materialName
          );

          if (!identifiableMaterial) {
            throw new Error(
              `Material "${materialName}" is not identifiable for this machine.`
            );
          }
          if (identifiableMaterial.category !== category) {
            throw new Error(
              `Material "${materialName}" does not match the provided category "${category}".`
            );
          }

          const material = await SortedMaterial.create({
            name: materialName,
            status: category === "recyclable" ? "recycled" : "non-recycled",
            machineId,
            orderId: machine.orderId,
            sortedAt: Date.now(),
          });

          await redis.del(`machine:${machineId}:sortedMaterials`);
          await redis.del(`machine:${machineId}:recycledMaterials`);
          await redis.del(`machine:${machineId}:nonRecycledMaterials`);
          await redis.del(`machine:${machineId}`);
          await redis.del("machines");

          return {
            recycledMaterials:
              category === "recyclable"
                ? [{ name: material.name, category }]
                : [],
            nonRecycledMaterials:
              category === "non-recyclable"
                ? [{ name: material.name, category }]
                : [],
          };
        } catch (err) {
          throw new Error(
            err.message || "Some error occurred while adding material"
          );
        }
      },
    },
  },
});

const schema = new GraphQLSchema({
  query: RootQuery,
  mutation: Mutation,
});

module.exports = schema;
