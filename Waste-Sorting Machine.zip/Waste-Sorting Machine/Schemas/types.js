const {
  GraphQLObjectType,
  GraphQLInputObjectType,
  GraphQLString,
  GraphQLNonNull,
  GraphQLBoolean,
  GraphQLList,
  GraphQLInt,
  GraphQLFloat,
} = require("graphql");

const UserType = new GraphQLObjectType({
  name: "User",
  fields: () => ({
    id: { type: new GraphQLNonNull(GraphQLString) },
    name: { type: new GraphQLNonNull(GraphQLString) },
    email: { type: new GraphQLNonNull(GraphQLString) },
    password: { type: new GraphQLNonNull(GraphQLString) },
    role: { type: new GraphQLNonNull(GraphQLString) },
    created_at: { type: new GraphQLNonNull(GraphQLString) },
    updated_at: { type: new GraphQLNonNull(GraphQLString) },
  }),
});

const AdminType = new GraphQLObjectType({
  name: "Admin",
  fields: () => ({
    id: { type: new GraphQLNonNull(GraphQLString) },
    name: { type: new GraphQLNonNull(GraphQLString) },
    email: { type: new GraphQLNonNull(GraphQLString) },
    password: { type: new GraphQLNonNull(GraphQLString) },
    role: { type: new GraphQLNonNull(GraphQLString) },
    created_at: { type: new GraphQLNonNull(GraphQLString) },
    updated_at: { type: new GraphQLNonNull(GraphQLString) },
  }),
});

const logInAuthPayload = new GraphQLObjectType({
  name: "logInAuthPayload",
  fields: {
    token: { type: new GraphQLNonNull(GraphQLString) },
    role: { type: new GraphQLNonNull(GraphQLString) },
  },
});

const UserAuthPayload = new GraphQLObjectType({
  name: "UserAuthPayload",
  fields: {
    token: { type: new GraphQLNonNull(GraphQLString) },
    user: {
      type: UserType,
    },
  },
});

const AdminAuthPayload = new GraphQLObjectType({
  name: "AdminAuthPayload",
  fields: {
    token: { type: new GraphQLNonNull(GraphQLString) },
    admin: {
      type: AdminType,
    },
  },
});

const MachineType = new GraphQLObjectType({
  name: "Machine",
  fields: {
    id: { type: new GraphQLNonNull(GraphQLString) },
    name: { type: new GraphQLNonNull(GraphQLString) },
    powerStatus: { type: new GraphQLNonNull(GraphQLBoolean) },
    maintenanceStatus: { type: new GraphQLNonNull(GraphQLBoolean) },
    orderId: { type: new GraphQLNonNull(GraphQLInt) },
    capacity: { type: new GraphQLNonNull(GraphQLInt) },
    locationLongitude: { type: new GraphQLNonNull(GraphQLFloat) },
    locationLatitude: { type: new GraphQLNonNull(GraphQLFloat) },
    createdAt: { type: new GraphQLNonNull(GraphQLString) },
    updatedAt: { type: new GraphQLNonNull(GraphQLString) },
  },
});

const IdentifiableMaterialType = new GraphQLObjectType({
  name: "IdentifiableMaterial",
  fields: {
    id: { type: new GraphQLNonNull(GraphQLString) },
    name: { type: new GraphQLNonNull(GraphQLString) },
    category: { type: new GraphQLNonNull(GraphQLString) },
    machineId: { type: new GraphQLNonNull(GraphQLString) },
  },
});

const SortedMaterialType = new GraphQLObjectType({
  name: "Material",
  fields: {
    id: { type: new GraphQLNonNull(GraphQLString) },
    name: { type: new GraphQLNonNull(GraphQLString) },
    status: { type: new GraphQLNonNull(GraphQLString) },
    machineId: { type: new GraphQLNonNull(GraphQLString) },
    sortedAt: { type: new GraphQLNonNull(GraphQLString) },
    orderId: { type: new GraphQLNonNull(GraphQLString) },
  },
});

const RetrieveMachineType = new GraphQLObjectType({
  name: "RetrieveMachine",
  fields: {
    machine: { type: MachineType },
    identifiableMaterials: { type: new GraphQLList(IdentifiableMaterialType) },
    sortedMaterials: { type: new GraphQLList(SortedMaterialType) },
  },
});

const AddMachineResponseType = new GraphQLObjectType({
  name: "AddMachineResponse",
  fields: {
    machine: { type: MachineType },
    identifiableMaterials: { type: new GraphQLList(IdentifiableMaterialType) },
  },
});

const AssignedMaterialType = new GraphQLInputObjectType({
  name: "AssignedMaterial",
  fields: {
    name: { type: new GraphQLNonNull(GraphQLString) },
  },
});

const CriteriaMaterialType = new GraphQLInputObjectType({
  name: "CriteriaMaterial",
  fields: {
    name: { type: new GraphQLNonNull(GraphQLString) },
    category: { type: new GraphQLNonNull(GraphQLString) },
  },
});

const validatMaterialsResponseType = new GraphQLObjectType({
  name: "ValidateMaterialsResponse",
  fields: {
    validatedMaterials: {
      type: new GraphQLList(
        new GraphQLObjectType({
          name: "ValidatedMaterial",
          fields: {
            name: { type: GraphQLString },
            category: { type: GraphQLString },
          },
        })
      ),
    },
    invalidMaterials: { type: new GraphQLList(GraphQLString) },
  },
});

const notificationType = new GraphQLObjectType({
  name: "Notification",
  fields: {
    title: { type: new GraphQLNonNull(GraphQLString) },
    message: { type: new GraphQLNonNull(GraphQLString) },
    machineId: { type: new GraphQLNonNull(GraphQLString) },
  },
});

const SortedMaterialResponseType = new GraphQLObjectType({
  name: "SortedMaterialResponse",
  fields: {
    notification: { type: notificationType },
    recycledMaterials: {
      type: new GraphQLList(
        new GraphQLObjectType({
          name: "RecycledMaterial",
          fields: {
            name: { type: GraphQLString },
            category: { type: GraphQLString },
          },
        })
      ),
    },
    nonRecycledMaterials: {
      type: new GraphQLList(
        new GraphQLObjectType({
          name: "nonRecycledMaterial",
          fields: {
            name: { type: GraphQLString },
            category: { type: GraphQLString },
          },
        })
      ),
    },
  },
});

const countMaterialResponseType = new GraphQLObjectType({
  name: "CountMaterialResponse",
  fields: {
    totalCount: { type: new GraphQLNonNull(GraphQLInt) },
    category: { type: new GraphQLNonNull(GraphQLString) },
  },
});

const alertType = new GraphQLObjectType({
  name: "Alert",
  fields: {
    id: { type: new GraphQLNonNull(GraphQLString) },
    title: { type: new GraphQLNonNull(GraphQLString) },
    message: { type: new GraphQLNonNull(GraphQLString) },
    machineId: { type: new GraphQLNonNull(GraphQLString) },
  },
});

reportMachineType = new GraphQLObjectType({
  name: "ReportMachine",
  fields: () => ({
    machineId: { type: new GraphQLNonNull(GraphQLString) },
    machineName: { type: new GraphQLNonNull(GraphQLString) },
    powerStatus: { type: new GraphQLNonNull(GraphQLBoolean) },
    maintenanceStatus: { type: new GraphQLNonNull(GraphQLBoolean) },
    capacity: { type: new GraphQLNonNull(GraphQLInt) },
    machineLocation: { type: new GraphQLNonNull(GraphQLList(GraphQLFloat)) },
    totalOrders: { type: new GraphQLNonNull(GraphQLInt) },
    totalIdentifiableMaterials: { type: new GraphQLNonNull(GraphQLInt) },
    totalSortedMaterials: { type: new GraphQLNonNull(GraphQLInt) },
    totalRecycledMaterials: { type: new GraphQLNonNull(GraphQLInt) },
    totalNonRecycledMaterials: { type: new GraphQLNonNull(GraphQLInt) },
  }),
});

reportMachinesType = new GraphQLObjectType({
  name: "ReportMachines",
  fields: () => ({
    machines: { type: new GraphQLNonNull(GraphQLList(reportMachineType)) },
    totalOrders: { type: new GraphQLNonNull(GraphQLInt) },
    totalIdentifiableMaterials: { type: new GraphQLNonNull(GraphQLInt) },
    totalSortedMaterials: { type: new GraphQLNonNull(GraphQLInt) },
    totalRecycledMaterials: { type: new GraphQLNonNull(GraphQLInt) },
    totalNonRecycledMaterials: { type: new GraphQLNonNull(GraphQLInt) },
  }),
});

module.exports = {
  UserType,
  AdminType,
  logInAuthPayload,
  UserAuthPayload,
  AdminAuthPayload,
  MachineType,
  IdentifiableMaterialType,
  SortedMaterialType,
  AssignedMaterialType,
  CriteriaMaterialType,
  RetrieveMachineType,
  AddMachineResponseType,
  validatMaterialsResponseType,
  SortedMaterialResponseType,
  countMaterialResponseType,
  notificationType,
  alertType,
  reportMachineType,
  reportMachinesType,
};
