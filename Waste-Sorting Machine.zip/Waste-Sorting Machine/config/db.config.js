module.exports = {
  HOST: "localhost",
  USER: "postgres",
  PASSWORD: "dareen333",
  DATABASE: "projectdb",
  dialect: "postgres",
  PORT: 5432,
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000,
  },
  dialectOptions: {
    ssl: {
      rejectUnauthorized: false,
    },
  },
};
