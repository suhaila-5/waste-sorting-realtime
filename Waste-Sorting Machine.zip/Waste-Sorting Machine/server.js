const express = require("express");
const { graphqlHTTP } = require("express-graphql");
const WebSocket = require("ws");
const http = require("http");

const schema = require("./Schemas/schema");
// const sequelize = require("./models").sequelize;

const cors = require("cors");

require("./services/mqttSubscriber");

const app = express();
var corsOptions = {
  origin: "http://localhost:8081",
};

app.use(cors(corsOptions));

app.use(
  "/graphql",
  graphqlHTTP({
    schema,
    graphiql: true,
  })
);

const db = require("./models");

db.sequelize
  .sync({ alter: true })
  .then(() => {
    console.log("Synced db.");
  })

  .catch((err) => {
    console.log("Failed to sync.db:" + err.message);
  });

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
wss.on("connection", (ws) => {
  console.log("A new WebSocket client has connected.");
  ws.on("message", (message) => {
    console.log(`Received: ${message}`);
    ws.send(`Hello from server! You said: ${message}`);
  });
  ws.on("close", () => {
    console.log("A WebSocket client has disconnected.");
  });
});

const PORT = process.env.PORT || 4000;

server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
