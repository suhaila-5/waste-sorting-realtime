const mqtt = require("mqtt");
const { graphqlRequest } = require("./graphqlClient");

const client = mqtt.connect("mqtt://localhost");

const topic = "waste/sorting";

client.on("connect", () => {
  console.log("Connected to MQTT broker");
  client.subscribe(topic, (err) => {
    if (err) {
      console.log(`Failed to subscribe to ${topic}:`, err);
    } else {
      console.log(`Subscribed to topic '${topic}'`);
    }
  });
});

client.on("message", async (topic, message) => {
  const [material, category, machineId] = message
    .toString()
    .split("|")
    .map((val) => val.trim());

  if (!material || !category || !machineId) {
    console.error("Invalid message received:", { material, category, machineId });
    return;
  }

  console.log(
    `Received material: ${material}, Category: ${category}, Machine ID: ${machineId}`
  );

  const mutation = `
    mutation {
      addMaterialFromMQTT(materialName: "${material}", category: "${category}", machineId: "${machineId}") {
        recycledMaterials {
          name
          category
        }
        nonRecycledMaterials {
          name
          category
        }
      }
    }
  `;

  try {
    const response = await graphqlRequest(mutation);
    console.log("GraphQL Response:", JSON.stringify(response, null, 2));
  } catch (error) {
    console.error("Error in processing GraphQL request:", error.message);
  }
});
