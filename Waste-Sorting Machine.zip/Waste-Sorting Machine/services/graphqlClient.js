const axios = require("axios");

const graphqlRequest = async (query) => {
  try {
    const response = await axios.post("http://localhost:4000/graphql", {
      query,
    });
    console.log("GraphQL Request Sent");
    console.log("GraphQL Response:", JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error("Error in GraphQL request:", error.message);
  }
};

module.exports = { graphqlRequest };
